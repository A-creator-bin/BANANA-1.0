"""
BANANA Semantic Analyzer
- Type checking
- User/security scope enforcement (root > a > b > c)
- Symbol table management
"""

from ast_nodes import *
from typing import Dict, List, Optional, Tuple


class SemanticError(Exception):
    def __init__(self, msg, line=0):
        super().__init__(f"[SemanticError] Line {line}: {msg}")
        self.line = line


# ─── Symbol Table ─────────────────────────────────────────────────────────────

class Symbol:
    def __init__(self, name: str, type_: Any, user_level: str, line: int = 0):
        self.name = name
        self.type_ = type_
        self.user_level = user_level  # who owns this symbol
        self.line = line

class Scope:
    def __init__(self, parent=None, user_ctx='root'):
        self.parent = parent
        self.user_ctx = user_ctx
        self.symbols: Dict[str, Symbol] = {}

    def define(self, sym: Symbol):
        self.symbols[sym.name] = sym

    def lookup(self, name: str, accessor: str) -> Optional[Symbol]:
        """Lookup with user access check."""
        if name in self.symbols:
            sym = self.symbols[name]
            if not can_access(accessor, sym.user_level):
                return None   # found but not accessible
            return sym
        if self.parent:
            return self.parent.lookup(name, accessor)
        return None

    def lookup_raw(self, name: str) -> Optional[Symbol]:
        """Lookup ignoring user access (for error messages)."""
        if name in self.symbols:
            return self.symbols[name]
        if self.parent:
            return self.parent.lookup_raw(name)
        return None


class FuncSig:
    def __init__(self, name, params, ret_type, user_level):
        self.name = name
        self.params = params      # list of (name, type)
        self.ret_type = ret_type
        self.user_level = user_level


# ─── Semantic Analyzer ────────────────────────────────────────────────────────

class Analyzer:
    def __init__(self):
        self.global_scope = Scope(user_ctx='root')
        self.current_scope = self.global_scope
        self.functions: Dict[str, FuncSig] = {}
        self.current_func: Optional[FuncSig] = None
        self.current_user = 'root'
        self.errors: List[str] = []
        self._setup_builtins()

    def _setup_builtins(self):
        """Register built-in functions."""
        builtins = [
            FuncSig('print_int',   [('v', TypeInt())],   TypeVoid(), 'root'),
            FuncSig('print_float', [('v', TypeFloat())], TypeVoid(), 'root'),
            FuncSig('print_char',  [('v', TypeChar())],  TypeVoid(), 'root'),
            FuncSig('print_str',   [('v', TypeArr(TypeChar()))], TypeVoid(), 'root'),
            FuncSig('int_to_float',[('v', TypeInt())],   TypeFloat(),'root'),
            FuncSig('float_to_int',[('v', TypeFloat())], TypeInt(),  'root'),
        ]
        for b in builtins:
            self.functions[b.name] = b

    def error(self, msg, line=0):
        err = SemanticError(msg, line)
        self.errors.append(str(err))
        # Don't raise — collect all errors

    def push_scope(self, user_ctx=None):
        ctx = user_ctx or self.current_user
        self.current_scope = Scope(parent=self.current_scope, user_ctx=ctx)

    def pop_scope(self):
        self.current_scope = self.current_scope.parent

    # ─── Type helpers ─────────────────────────────────────────────────────────

    def type_str(self, t) -> str:
        if isinstance(t, TypeInt):   return 'int'
        if isinstance(t, TypeFloat): return 'float'
        if isinstance(t, TypeChar):  return 'char'
        if isinstance(t, TypeVoid):  return 'void'
        if isinstance(t, TypeArr):   return f'arr[{self.type_str(t.elem_type)}]'
        return '?'

    def types_eq(self, a, b) -> bool:
        if type(a) != type(b):
            return False
        if isinstance(a, TypeArr):
            return self.types_eq(a.elem_type, b.elem_type)
        return True

    def is_numeric(self, t):
        return isinstance(t, (TypeInt, TypeFloat))

    def arithmetic_result(self, a, b):
        if isinstance(a, TypeFloat) or isinstance(b, TypeFloat):
            return TypeFloat()
        return TypeInt()

    # ─── Program ──────────────────────────────────────────────────────────────

    def analyze(self, prog: Program):
        # First pass: register all function signatures
        for f in prog.funcs:
            if f.name in self.functions:
                self.error(f"Function '{f.name}' already defined", f.line)
            else:
                self.functions[f.name] = FuncSig(
                    f.name,
                    [(p.name, p.type_) for p in f.params],
                    f.ret_type,
                    f.user_level
                )

        # Analyze globals
        for gv in prog.globals_:
            self.analyze_var_decl(gv)

        # Analyze functions
        for f in prog.funcs:
            self.analyze_func(f)

        if self.errors:
            raise SemanticError('\n'.join(self.errors))

    def analyze_func(self, func: FuncDef):
        old_user = self.current_user
        self.current_user = func.user_level

        sig = self.functions[func.name]
        self.current_func = sig

        self.push_scope(func.user_level)
        for pname, ptype in sig.params:
            sym = Symbol(pname, ptype, func.user_level, func.line)
            self.current_scope.define(sym)

        self.analyze_block(func.body)
        self.pop_scope()

        self.current_func = None
        self.current_user = old_user

    def analyze_block(self, block: Block):
        self.push_scope(block.user_ctx)
        for stmt in block.stmts:
            self.analyze_stmt(stmt)
        self.pop_scope()

    # ─── Statements ───────────────────────────────────────────────────────────

    def analyze_stmt(self, stmt):
        if stmt is None:
            return

        if isinstance(stmt, VarDecl):
            self.analyze_var_decl(stmt)

        elif isinstance(stmt, RetStmt):
            if self.current_func is None:
                self.error("'ret' outside function", stmt.line)
                return
            if stmt.value is not None:
                vtype = self.analyze_expr(stmt.value)
                if not self.types_eq(vtype, self.current_func.ret_type):
                    self.error(
                        f"Return type mismatch: expected {self.type_str(self.current_func.ret_type)}, "
                        f"got {self.type_str(vtype)}",
                        stmt.line
                    )
            else:
                if not isinstance(self.current_func.ret_type, TypeVoid):
                    self.error("Non-void function missing return value", stmt.line)

        elif isinstance(stmt, IfStmt):
            ctype = self.analyze_expr(stmt.cond)
            self.analyze_block(stmt.then_block)
            if stmt.else_block:
                if isinstance(stmt.else_block, Block):
                    self.analyze_block(stmt.else_block)
                else:
                    self.analyze_stmt(stmt.else_block)

        elif isinstance(stmt, WhileStmt):
            self.analyze_expr(stmt.cond)
            self.analyze_block(stmt.body)

        elif isinstance(stmt, ForStmt):
            self.push_scope()
            if stmt.init:
                if isinstance(stmt.init, VarDecl):
                    self.analyze_var_decl(stmt.init)
                else:
                    self.analyze_expr(stmt.init)
            if stmt.cond:
                self.analyze_expr(stmt.cond)
            if stmt.step:
                self.analyze_expr(stmt.step)
            self.analyze_block(stmt.body)
            self.pop_scope()

        elif isinstance(stmt, MudStmt):
            # Security: can only mud to same or lower privilege
            if user_level(stmt.target_user) < user_level(self.current_user):
                self.error(
                    f"Security violation: user '{self.current_user}' cannot escalate to '{stmt.target_user}'",
                    stmt.line
                )
            old_user = self.current_user
            self.current_user = stmt.target_user
            self.analyze_block(stmt.body)
            self.current_user = old_user

        elif isinstance(stmt, ExprStmt):
            self.analyze_expr(stmt.expr)

        elif isinstance(stmt, Block):
            self.analyze_block(stmt)

        else:
            self.error(f"Unknown statement type: {type(stmt).__name__}")

    def analyze_var_decl(self, decl: VarDecl):
        # Check if user can declare at this level
        if user_level(decl.user_level) < user_level(self.current_user):
            self.error(
                f"Security violation: user '{self.current_user}' cannot declare variables "
                f"owned by higher-privilege user '{decl.user_level}'",
                decl.line
            )

        init_type = None
        if decl.init is not None:
            init_type = self.analyze_expr(decl.init)
            if init_type and not self.types_eq(init_type, decl.type_):
                # Allow int -> float implicit coercion
                if isinstance(decl.type_, TypeFloat) and isinstance(init_type, TypeInt):
                    pass  # ok
                # Allow 0 as array zero-initializer
                elif isinstance(decl.type_, TypeArr) and isinstance(init_type, TypeInt):
                    pass  # ok - zero init for arrays
                else:
                    self.error(
                        f"Type mismatch in var '{decl.name}': "
                        f"declared {self.type_str(decl.type_)}, "
                        f"got {self.type_str(init_type)}",
                        decl.line
                    )

        sym = Symbol(decl.name, decl.type_, decl.user_level, decl.line)
        self.current_scope.define(sym)

    # ─── Expressions ──────────────────────────────────────────────────────────

    def analyze_expr(self, expr) -> Any:
        if expr is None:
            return TypeVoid()

        if isinstance(expr, IntLit):
            return TypeInt()

        if isinstance(expr, FloatLit):
            return TypeFloat()

        if isinstance(expr, CharLit):
            return TypeChar()

        if isinstance(expr, StringLit):
            return TypeArr(TypeChar())

        if isinstance(expr, Ident):
            sym = self.current_scope.lookup(expr.name, self.current_user)
            if sym is None:
                raw = self.current_scope.lookup_raw(expr.name)
                if raw:
                    self.error(
                        f"Security violation: user '{self.current_user}' cannot access "
                        f"variable '{expr.name}' owned by '{raw.user_level}'",
                        expr.line
                    )
                else:
                    self.error(f"Undefined variable '{expr.name}'", expr.line)
                return TypeInt()  # recovery
            return sym.type_

        if isinstance(expr, BinOp):
            lt = self.analyze_expr(expr.left)
            rt = self.analyze_expr(expr.right)
            if expr.op in ('+', '-', '*', '/'):
                if not (self.is_numeric(lt) and self.is_numeric(rt)):
                    self.error(
                        f"Arithmetic op '{expr.op}' requires numeric types, "
                        f"got {self.type_str(lt)} and {self.type_str(rt)}",
                        expr.line
                    )
                return self.arithmetic_result(lt, rt)
            if expr.op == '^':
                return self.arithmetic_result(lt, rt)
            if expr.op in ('==', '!=', '<', '>', '<=', '>='):
                return TypeInt()  # booleans as int
            if expr.op in ('&&', '||'):
                return TypeInt()
            return TypeInt()

        if isinstance(expr, UnaryOp):
            t = self.analyze_expr(expr.operand)
            if expr.op == '-':
                if not self.is_numeric(t):
                    self.error(f"Unary minus requires numeric type", expr.line)
                return t
            if expr.op == '!':
                return TypeInt()
            if expr.op == '&':
                return TypeArr(t)  # pointer-like
            return t

        if isinstance(expr, Assign):
            tt = self.analyze_expr(expr.target)
            vt = self.analyze_expr(expr.value)
            if not self.types_eq(tt, vt):
                if isinstance(tt, TypeFloat) and isinstance(vt, TypeInt):
                    pass
                else:
                    self.error(
                        f"Assignment type mismatch: {self.type_str(tt)} = {self.type_str(vt)}",
                        expr.line
                    )
            return tt

        if isinstance(expr, Index):
            at = self.analyze_expr(expr.array)
            it = self.analyze_expr(expr.idx)
            if not isinstance(at, TypeArr):
                self.error(f"Index on non-array type {self.type_str(at)}", expr.line)
                return TypeInt()
            if not isinstance(it, TypeInt):
                self.error("Array index must be int", expr.line)
            return at.elem_type

        if isinstance(expr, Call):
            sig = self.functions.get(expr.name)
            if sig is None:
                self.error(f"Undefined function '{expr.name}'", expr.line)
                return TypeVoid()
            if len(expr.args) != len(sig.params):
                self.error(
                    f"Function '{expr.name}' expects {len(sig.params)} args, "
                    f"got {len(expr.args)}",
                    expr.line
                )
            for i, (arg, (pname, ptype)) in enumerate(zip(expr.args, sig.params)):
                at = self.analyze_expr(arg)
                if not self.types_eq(at, ptype):
                    if isinstance(ptype, TypeFloat) and isinstance(at, TypeInt):
                        pass
                    else:
                        self.error(
                            f"Arg {i+1} of '{expr.name}': expected {self.type_str(ptype)}, "
                            f"got {self.type_str(at)}",
                            expr.line
                        )
            return sig.ret_type

        if isinstance(expr, Ternary):
            self.analyze_expr(expr.cond)
            tt = self.analyze_expr(expr.then_expr)
            et = self.analyze_expr(expr.else_expr)
            return tt

        if isinstance(expr, FieldAccess):
            self.analyze_expr(expr.obj)
            return TypeInt()  # simplified

        self.error(f"Unknown expr type: {type(expr).__name__}")
        return TypeVoid()
