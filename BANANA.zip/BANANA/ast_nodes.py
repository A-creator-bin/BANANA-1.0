"""
BANANA Language AST Nodes
All Abstract Syntax Tree node types for the BANANA language
"""

from dataclasses import dataclass, field
from typing import Optional, List, Any


# ─── User/Security levels ────────────────────────────────────────────────────

USERS = ['root', 'a', 'b', 'c']
USER_LEVELS = {u: i for i, u in enumerate(USERS)}

def user_level(u: str) -> int:
    return USER_LEVELS.get(u, -1)

def can_access(accessor: str, owner: str) -> bool:
    """Root can access all; users can only access same or higher-level (parent) vars."""
    return user_level(accessor) <= user_level(owner)


# ─── Type nodes ──────────────────────────────────────────────────────────────

@dataclass
class TypeInt:
    pass

@dataclass
class TypeFloat:
    pass

@dataclass
class TypeChar:
    pass

@dataclass
class TypeVoid:
    pass

@dataclass
class TypeArr:
    elem_type: Any  # nested type
    size: Optional[Any] = None  # expr or None for dynamic


# ─── Expression nodes ────────────────────────────────────────────────────────

@dataclass
class IntLit:
    value: int
    line: int = 0

@dataclass
class FloatLit:
    value: float
    line: int = 0

@dataclass
class CharLit:
    value: str
    line: int = 0

@dataclass
class StringLit:
    value: str
    line: int = 0

@dataclass
class Ident:
    name: str
    line: int = 0

@dataclass
class BinOp:
    op: str      # '+' '-' '*' '/' '^' '==' '!=' '<' '>' '<=' '>=' '&&' '||'
    left: Any
    right: Any
    line: int = 0

@dataclass
class UnaryOp:
    op: str      # '-' '!' '&'
    operand: Any
    line: int = 0

@dataclass
class Assign:
    target: Any  # Ident or Index
    value: Any
    line: int = 0

@dataclass
class Index:
    array: Any
    idx: Any
    line: int = 0

@dataclass
class Call:
    name: str
    args: List[Any]
    line: int = 0

@dataclass
class Ternary:
    cond: Any
    then_expr: Any
    else_expr: Any
    line: int = 0

@dataclass
class FieldAccess:
    obj: Any
    field: str
    line: int = 0


# ─── Statement nodes ─────────────────────────────────────────────────────────

@dataclass
class VarDecl:
    """var x: int = expr   or   var x: arr[int][10] = ..."""
    user_level: str          # which user owns this var
    name: str
    type_: Any
    init: Optional[Any]
    line: int = 0

@dataclass
class RetStmt:
    value: Optional[Any]
    line: int = 0

@dataclass
class IfStmt:
    cond: Any
    then_block: Any          # Block
    else_block: Optional[Any]
    line: int = 0

@dataclass
class WhileStmt:
    cond: Any
    body: Any                # Block
    line: int = 0

@dataclass
class ForStmt:
    init: Optional[Any]      # VarDecl or Assign or expr
    cond: Optional[Any]
    step: Optional[Any]
    body: Any                # Block
    line: int = 0

@dataclass
class MudStmt:
    """mud a { ... }  — run block as user 'a'"""
    target_user: str
    body: Any                # Block
    line: int = 0

@dataclass
class ExprStmt:
    expr: Any
    line: int = 0

@dataclass
class Block:
    stmts: List[Any]
    user_ctx: str = 'root'   # which user context owns this block
    line: int = 0


# ─── Top-level ───────────────────────────────────────────────────────────────

@dataclass
class Param:
    name: str
    type_: Any

@dataclass
class FuncDef:
    user_level: str           # which user defined this function
    name: str
    params: List[Param]
    ret_type: Any
    body: Block
    line: int = 0

@dataclass
class Program:
    funcs: List[FuncDef]
    globals_: List[VarDecl] = field(default_factory=list)
