"""
BANANA Language Parser
Recursive-descent parser producing an AST
"""

from lexer import TokenType, Token, Lexer
from ast_nodes import *


class ParseError(Exception):
    def __init__(self, msg, line, col):
        super().__init__(f"[ParseError] Line {line}, Col {col}: {msg}")
        self.line = line
        self.col = col


class Parser:
    def __init__(self, tokens: list):
        self.tokens = tokens
        self.pos = 0
        self.current_user = 'root'

    def peek(self, offset=0) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]  # EOF

    def advance(self) -> Token:
        tok = self.tokens[self.pos]
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return tok

    def check(self, *types) -> bool:
        return self.peek().type in types

    def match(self, *types) -> Optional[Token]:
        if self.check(*types):
            return self.advance()
        return None

    def expect(self, ttype, msg=None) -> Token:
        tok = self.peek()
        if tok.type != ttype:
            raise ParseError(
                msg or f"Expected {ttype.name}, got {tok.type.name} ({tok.value!r})",
                tok.line, tok.col
            )
        return self.advance()

    def error(self, msg):
        tok = self.peek()
        raise ParseError(msg, tok.line, tok.col)

    # ─── Type parsing ────────────────────────────────────────────────────────

    def parse_type(self):
        tok = self.peek()
        if tok.type == TokenType.INT:
            self.advance()
            return TypeInt()
        elif tok.type == TokenType.FLOAT:
            self.advance()
            return TypeFloat()
        elif tok.type == TokenType.CHAR:
            self.advance()
            return TypeChar()
        elif tok.type == TokenType.ARR:
            self.advance()
            self.expect(TokenType.LBRACKET, "Expected '[' after 'arr'")
            elem = self.parse_type()
            self.expect(TokenType.RBRACKET, "Expected ']' after array element type")
            size = None
            if self.match(TokenType.LBRACKET):
                size = self.parse_expr()
                self.expect(TokenType.RBRACKET)
            return TypeArr(elem, size)
        else:
            self.error(f"Expected type, got {tok.value!r}")

    # ─── Program ─────────────────────────────────────────────────────────────

    def parse_program(self) -> Program:
        funcs = []
        globals_ = []
        while not self.check(TokenType.EOF):
            item = self.parse_top_level()
            if isinstance(item, FuncDef):
                funcs.append(item)
            elif isinstance(item, VarDecl):
                globals_.append(item)
            else:
                self.error("Unexpected top-level item")
        return Program(funcs=funcs, globals_=globals_)

    def parse_top_level(self):
        tok = self.peek()

        # Optional user prefix: root func ... / a func ...
        user = 'root'
        if tok.type in (TokenType.ROOT, TokenType.USER_A, TokenType.USER_B, TokenType.USER_C):
            user_tok = self.advance()
            user = user_tok.value
            tok = self.peek()

        if tok.type == TokenType.FUNC:
            return self.parse_func(user)
        elif tok.type == TokenType.VAR:
            decl = self.parse_var_decl(user)
            self.expect(TokenType.SEMICOLON, "Expected ';' after global var declaration")
            return decl
        else:
            self.error(f"Expected 'func' or 'var' at top level, got {tok.value!r}")

    # ─── Function ────────────────────────────────────────────────────────────

    def parse_func(self, user='root') -> FuncDef:
        line = self.peek().line
        self.expect(TokenType.FUNC)
        name_tok = self.expect(TokenType.IDENT, "Expected function name")
        self.expect(TokenType.LPAREN)

        params = []
        if not self.check(TokenType.RPAREN):
            params = self.parse_param_list()
        self.expect(TokenType.RPAREN)

        # Return type: func name(...) : type { ... }  or void if no colon
        ret_type = TypeVoid()
        if self.match(TokenType.COLON):
            ret_type = self.parse_type()

        old_user = self.current_user
        self.current_user = user
        body = self.parse_block()
        self.current_user = old_user

        return FuncDef(user_level=user, name=name_tok.value,
                       params=params, ret_type=ret_type,
                       body=body, line=line)

    def parse_param_name(self) -> Token:
        """Accept IDENT or user-level keywords (a/b/c/root) as param names."""
        tok = self.peek()
        if tok.type in (TokenType.IDENT, TokenType.ROOT,
                        TokenType.USER_A, TokenType.USER_B, TokenType.USER_C):
            return self.advance()
        self.error(f"Expected parameter name, got {tok.value!r}")

    def parse_param_list(self) -> list:
        params = []
        pname = self.parse_param_name()
        self.expect(TokenType.COLON, "Expected ':' after param name")
        ptype = self.parse_type()
        params.append(Param(pname.value, ptype))
        while self.match(TokenType.COMMA):
            pname = self.parse_param_name()
            self.expect(TokenType.COLON, "Expected ':' after param name")
            ptype = self.parse_type()
            params.append(Param(pname.value, ptype))
        return params

    # ─── Block ───────────────────────────────────────────────────────────────

    def parse_block(self) -> Block:
        line = self.peek().line
        self.expect(TokenType.LBRACE)
        stmts = []
        while not self.check(TokenType.RBRACE) and not self.check(TokenType.EOF):
            s = self.parse_stmt()
            if s is not None:
                stmts.append(s)
        self.expect(TokenType.RBRACE)
        return Block(stmts=stmts, user_ctx=self.current_user, line=line)

    # ─── Statements ──────────────────────────────────────────────────────────

    def parse_stmt(self):
        tok = self.peek()

        if tok.type == TokenType.SEMICOLON:
            self.advance()
            return None

        # user-prefixed var decl: a var x: int = 5;
        user_prefix = None
        if tok.type in (TokenType.ROOT, TokenType.USER_A, TokenType.USER_B, TokenType.USER_C):
            next_tok = self.peek(1)
            if next_tok.type in (TokenType.VAR, TokenType.FUNC):
                user_prefix = self.advance().value
                tok = self.peek()

        if tok.type == TokenType.VAR:
            u = user_prefix or self.current_user
            decl = self.parse_var_decl(u)
            self.expect(TokenType.SEMICOLON, "Expected ';' after var declaration")
            return decl

        if tok.type == TokenType.RET:
            return self.parse_ret()

        if tok.type == TokenType.IF:
            return self.parse_if()

        if tok.type == TokenType.WHILE:
            return self.parse_while()

        if tok.type == TokenType.FOR:
            return self.parse_for()

        if tok.type == TokenType.MUD:
            return self.parse_mud()

        if tok.type == TokenType.LBRACE:
            return self.parse_block()

        # Expression statement (assign or call etc.)
        line = tok.line
        expr = self.parse_expr()
        self.expect(TokenType.SEMICOLON, "Expected ';' after expression")
        return ExprStmt(expr=expr, line=line)

    def parse_var_decl(self, user='root') -> VarDecl:
        line = self.peek().line
        self.expect(TokenType.VAR)
        name = self.expect(TokenType.IDENT, "Expected variable name").value
        self.expect(TokenType.COLON, "Expected ':' after var name")
        type_ = self.parse_type()
        init = None
        if self.match(TokenType.EQ):
            init = self.parse_expr()
        return VarDecl(user_level=user, name=name, type_=type_, init=init, line=line)

    def parse_ret(self) -> RetStmt:
        line = self.peek().line
        self.expect(TokenType.RET)
        if self.check(TokenType.SEMICOLON):
            self.advance()
            return RetStmt(value=None, line=line)
        val = self.parse_expr()
        self.expect(TokenType.SEMICOLON, "Expected ';' after ret")
        return RetStmt(value=val, line=line)

    def parse_if(self) -> IfStmt:
        line = self.peek().line
        self.expect(TokenType.IF)
        self.expect(TokenType.LPAREN, "Expected '(' after 'if'")
        cond = self.parse_expr()
        self.expect(TokenType.RPAREN, "Expected ')' after if condition")
        then_block = self.parse_block()
        else_block = None
        if self.match(TokenType.ELSE):
            if self.check(TokenType.IF):
                else_block = self.parse_if()
            else:
                else_block = self.parse_block()
        return IfStmt(cond=cond, then_block=then_block, else_block=else_block, line=line)

    def parse_while(self) -> WhileStmt:
        line = self.peek().line
        self.expect(TokenType.WHILE)
        self.expect(TokenType.LPAREN, "Expected '(' after 'while'")
        cond = self.parse_expr()
        self.expect(TokenType.RPAREN, "Expected ')' after while condition")
        body = self.parse_block()
        return WhileStmt(cond=cond, body=body, line=line)

    def parse_for(self) -> ForStmt:
        line = self.peek().line
        self.expect(TokenType.FOR)
        self.expect(TokenType.LPAREN, "Expected '(' after 'for'")

        # init
        init = None
        if not self.check(TokenType.SEMICOLON):
            if self.check(TokenType.VAR):
                init = self.parse_var_decl(self.current_user)
            else:
                init = self.parse_expr()
        self.expect(TokenType.SEMICOLON)

        # cond
        cond = None
        if not self.check(TokenType.SEMICOLON):
            cond = self.parse_expr()
        self.expect(TokenType.SEMICOLON)

        # step
        step = None
        if not self.check(TokenType.RPAREN):
            step = self.parse_expr()
        self.expect(TokenType.RPAREN)

        body = self.parse_block()
        return ForStmt(init=init, cond=cond, step=step, body=body, line=line)

    def parse_mud(self) -> MudStmt:
        """mud a { ... }  — switch user context"""
        line = self.peek().line
        self.expect(TokenType.MUD)
        tok = self.peek()
        if tok.type not in (TokenType.ROOT, TokenType.USER_A, TokenType.USER_B, TokenType.USER_C):
            self.error(f"Expected user name (root/a/b/c) after 'mud', got {tok.value!r}")
        target = self.advance().value

        old_user = self.current_user
        self.current_user = target
        body = self.parse_block()
        self.current_user = old_user

        return MudStmt(target_user=target, body=body, line=line)

    # ─── Expressions (Pratt / precedence climbing) ───────────────────────────

    def parse_expr(self):
        return self.parse_assign()

    def parse_assign(self):
        left = self.parse_ternary()
        if self.check(TokenType.EQ):
            line = self.peek().line
            self.advance()
            right = self.parse_assign()
            if not isinstance(left, (Ident, Index, FieldAccess)):
                raise ParseError("Invalid assignment target", line, 0)
            return Assign(target=left, value=right, line=line)
        return left

    def parse_ternary(self):
        cond = self.parse_or()
        if self.match(TokenType.QUESTION):
            then = self.parse_expr()
            self.expect(TokenType.COLON, "Expected ':' in ternary expression")
            else_ = self.parse_expr()
            return Ternary(cond=cond, then_expr=then, else_expr=else_)
        return cond

    def parse_or(self):
        left = self.parse_and()
        while self.check(TokenType.PIPE_PIPE):
            op = self.advance().value
            right = self.parse_and()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_and(self):
        left = self.parse_equality()
        while self.check(TokenType.AMP_AMP):
            op = self.advance().value
            right = self.parse_equality()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_equality(self):
        left = self.parse_relational()
        while self.check(TokenType.EQ_EQ, TokenType.NEQ):
            op = self.advance().value
            right = self.parse_relational()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_relational(self):
        left = self.parse_additive()
        while self.check(TokenType.LT, TokenType.GT, TokenType.LTE, TokenType.GTE):
            op = self.advance().value
            right = self.parse_additive()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_additive(self):
        left = self.parse_multiplicative()
        while self.check(TokenType.PLUS, TokenType.MINUS):
            op = self.advance().value
            right = self.parse_multiplicative()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_multiplicative(self):
        left = self.parse_power()
        while self.check(TokenType.STAR, TokenType.SLASH):
            op = self.advance().value
            right = self.parse_power()
            left = BinOp(op=op, left=left, right=right)
        return left

    def parse_power(self):
        base = self.parse_unary()
        if self.check(TokenType.CARET):
            op = self.advance().value
            exp_ = self.parse_power()  # right-associative
            return BinOp(op=op, left=base, right=exp_)
        return base

    def parse_unary(self):
        tok = self.peek()
        if tok.type == TokenType.MINUS:
            self.advance()
            return UnaryOp(op='-', operand=self.parse_unary())
        if tok.type == TokenType.BANG:
            self.advance()
            return UnaryOp(op='!', operand=self.parse_unary())
        if tok.type == TokenType.AMP:
            self.advance()
            return UnaryOp(op='&', operand=self.parse_unary())
        return self.parse_postfix()

    def parse_postfix(self):
        expr = self.parse_primary()
        while True:
            if self.check(TokenType.LBRACKET):
                line = self.peek().line
                self.advance()
                idx = self.parse_expr()
                self.expect(TokenType.RBRACKET)
                expr = Index(array=expr, idx=idx, line=line)
            elif self.check(TokenType.DOT):
                line = self.peek().line
                self.advance()
                field = self.expect(TokenType.IDENT, "Expected field name after '.'").value
                expr = FieldAccess(obj=expr, field=field, line=line)
            else:
                break
        return expr

    def parse_primary(self):
        tok = self.peek()

        if tok.type == TokenType.INT_LIT:
            self.advance()
            return IntLit(value=int(tok.value), line=tok.line)

        if tok.type == TokenType.FLOAT_LIT:
            self.advance()
            return FloatLit(value=float(tok.value), line=tok.line)

        if tok.type == TokenType.CHAR_LIT:
            self.advance()
            return CharLit(value=tok.value, line=tok.line)

        if tok.type == TokenType.STRING_LIT:
            self.advance()
            return StringLit(value=tok.value, line=tok.line)

        if tok.type in (TokenType.IDENT, TokenType.ROOT,
                        TokenType.USER_A, TokenType.USER_B, TokenType.USER_C):
            self.advance()
            name = tok.value
            # Function call?
            if self.check(TokenType.LPAREN):
                self.advance()
                args = []
                if not self.check(TokenType.RPAREN):
                    args.append(self.parse_expr())
                    while self.match(TokenType.COMMA):
                        args.append(self.parse_expr())
                self.expect(TokenType.RPAREN)
                return Call(name=name, args=args, line=tok.line)
            return Ident(name=name, line=tok.line)

        if tok.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expr()
            self.expect(TokenType.RPAREN, "Expected ')'")
            return expr

        self.error(f"Unexpected token in expression: {tok.value!r} ({tok.type.name})")
