#!/usr/bin/env python3
"""
BANANA Compiler
Usage: python3 bananac.py <source.bn> [-o output] [-S] [-v]

Flags:
  -o <name>   Output binary name (default: a.out)
  -S          Emit C source only (don't compile)
  -v          Verbose mode
  --check     Semantic check only (no codegen)
"""

import sys
import os
import subprocess
import argparse
import tempfile

# Add banana directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lexer import Lexer, LexerError
from parser import Parser, ParseError
from analyzer import Analyzer, SemanticError
from codegen import Codegen, CodegenError


BANNER = r"""
  ██████╗  █████╗ ███╗   ██╗ █████╗ ███╗   ██╗ █████╗ 
  ██╔══██╗██╔══██╗████╗  ██║██╔══██╗████╗  ██║██╔══██╗
  ██████╔╝███████║██╔██╗ ██║███████║██╔██╗ ██║███████║
  ██╔══██╗██╔══██║██║╚██╗██║██╔══██║██║╚██╗██║██╔══██║
  ██████╔╝██║  ██║██║ ╚████║██║  ██║██║ ╚████║██║  ██║
  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝
  BANANA Language Compiler v1.0  |  Security Levels: root > a > b > c
"""


def compile_file(source_path: str, output: str = 'a',
                 emit_c: bool = False, verbose: bool = False,
                 check_only: bool = False) -> bool:

    if verbose:
        print(BANNER)

    # Read source
    try:
        with open(source_path, 'r') as f:
            source = f.read()
    except FileNotFoundError:
        print(f"Error: File not found: {source_path}", file=sys.stderr)
        return False

    print(f"🍌 Compiling: {source_path}")

    # ── Phase 1: Lexing ──────────────────────────────────────────────────────
    try:
        lexer = Lexer(source)
        tokens = lexer.tokenize()
        if verbose:
            print(f"  [1/4] Lexer  ✓  ({len(tokens)} tokens)")
    except LexerError as e:
        print(f"  [1/4] Lexer  ✗\n  {e}", file=sys.stderr)
        return False

    # ── Phase 2: Parsing ─────────────────────────────────────────────────────
    try:
        parser = Parser(tokens)
        ast = parser.parse_program()
        if verbose:
            n_funcs = len(ast.funcs)
            print(f"  [2/4] Parser ✓  ({n_funcs} function(s), {len(ast.globals_)} global(s))")
    except ParseError as e:
        print(f"  [2/4] Parser ✗\n  {e}", file=sys.stderr)
        return False

    # ── Phase 3: Semantic Analysis + Security Checks ─────────────────────────
    try:
        analyzer = Analyzer()
        analyzer.analyze(ast)
        if verbose:
            print(f"  [3/4] Semantic Analysis + Security ✓")
    except SemanticError as e:
        print(f"  [3/4] Semantic Analysis ✗\n  {e}", file=sys.stderr)
        return False

    if check_only:
        print("  ✓ Semantic check passed (no codegen requested)")
        return True

    # ── Phase 4: Code Generation ─────────────────────────────────────────────
    try:
        codegen = Codegen()
        c_code = codegen.generate(ast)
        if verbose:
            print(f"  [4/4] Codegen ✓  ({len(c_code)} chars of C)")
    except CodegenError as e:
        print(f"  [4/4] Codegen ✗\n  {e}", file=sys.stderr)
        return False

    # ── Emit C source ────────────────────────────────────────────────────────
    if emit_c:
        c_out = output if output.endswith('.c') else (output + '.c')
        with open(c_out, 'w') as f:
            f.write(c_code)
        print(f"  ✓ C source written to: {c_out}")
        return True

    # ── Compile with GCC ─────────────────────────────────────────────────────
    with tempfile.NamedTemporaryFile(suffix='.c', mode='w',
                                     delete=False, prefix='banana_') as tf:
        tf.write(c_code)
        tmp_c = tf.name

    try:
        gcc_cmd = ['gcc', '-O2', '-lm', '-o', output, tmp_c]
        if verbose:
            print(f"  GCC: {' '.join(gcc_cmd)}")
        result = subprocess.run(gcc_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"  GCC error:\n{result.stderr}", file=sys.stderr)
            return False
    finally:
        os.unlink(tmp_c)

    print(f"  ✓ Binary: {output}")
    print(f"  🔐 Security model: root > a > b > c (enforced)")
    return True


def run_repl():
    """Interactive BANANA REPL (evaluates expressions)."""
    print(BANNER)
    print("BANANA REPL — type 'exit' to quit")
    print("Tip: Wrap code in func main() { ... } or enter expressions\n")

    import tempfile, os
    session_funcs = []

    while True:
        try:
            line = input("🍌> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if line in ('exit', 'quit'):
            break
        if not line:
            continue

        # Wrap in main if not a function definition
        if not line.startswith('func') and not line.startswith('root') \
           and not line.startswith('a ') and not line.startswith('b ') \
           and not line.startswith('c '):
            src = f"func main() : int {{ {line} ret 0; }}\n"
        else:
            src = line + '\n'

        with tempfile.NamedTemporaryFile(suffix='.bn', mode='w',
                                          delete=False, prefix='repl_') as tf:
            tf.write(src)
            tmp_src = tf.name

        try:
            ok = compile_file(tmp_src, '/tmp/banana_repl_out', verbose=False)
            if ok:
                r = subprocess.run(['/tmp/banana_repl_out'], capture_output=True, text=True)
                if r.stdout:
                    print(r.stdout, end='')
                if r.stderr:
                    print(r.stderr, end='', file=sys.stderr)
        finally:
            os.unlink(tmp_src)


def main():
    parser = argparse.ArgumentParser(
        prog='bananac',
        description='🍌 BANANA Language Compiler',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  bananac hello.bn              Compile to a
  bananac hello.bn -o hello     Compile to hello
  bananac hello.bn -S           Emit C source
  bananac hello.bn --check      Type/security check only
  bananac --repl                Interactive REPL
        """
    )
    parser.add_argument('source', nargs='?', help='Source file (.bn)')
    parser.add_argument('-o', '--output', default='a', help='Output file')
    parser.add_argument('-S', '--emit-c', action='store_true', help='Emit C source')
    parser.add_argument('-v', '--verbose', action='store_true', help='Verbose')
    parser.add_argument('--check', action='store_true', help='Semantic check only')
    parser.add_argument('--repl', action='store_true', help='Interactive REPL')

    args = parser.parse_args()

    if args.repl:
        run_repl()
        return

    if not args.source:
        print(BANNER)
        parser.print_help()
        return

    ok = compile_file(
        args.source,
        output=args.output,
        emit_c=args.emit_c,
        verbose=args.verbose,
        check_only=args.check
    )
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
