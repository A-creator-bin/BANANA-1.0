"""
BANANA Language Lexer
Tokens for the BANANA programming language
"""

import re
from enum import Enum, auto
from dataclasses import dataclass
from typing import Optional

class TokenType(Enum):
    # Keywords
    FUNC    = auto()
    RET     = auto()
    INT     = auto()
    FLOAT   = auto()
    CHAR    = auto()
    ARR     = auto()
    WHILE   = auto()
    IF      = auto()
    ELSE    = auto()
    FOR     = auto()
    MUD     = auto()   # mudar de usuario
    VAR     = auto()

    # User levels
    ROOT    = auto()
    USER_A  = auto()
    USER_B  = auto()
    USER_C  = auto()

    # Literals
    INT_LIT     = auto()
    FLOAT_LIT   = auto()
    CHAR_LIT    = auto()
    STRING_LIT  = auto()
    IDENT       = auto()

    # Operators
    PLUS    = auto()   # +
    MINUS   = auto()   # -
    STAR    = auto()   # *
    SLASH   = auto()   # /
    CARET   = auto()   # ^  (power)
    EQ      = auto()   # =
    EQ_EQ   = auto()   # ==
    BANG    = auto()   # !
    NEQ     = auto()   # !=
    LT      = auto()   # <
    GT      = auto()   # >
    LTE     = auto()   # <=
    GTE     = auto()   # >=
    AMP     = auto()   # &  (address-of / ref)
    AMP_AMP = auto()   # &&
    PIPE    = auto()   # |
    PIPE_PIPE = auto() # ||
    DOT     = auto()   # .
    COMMA   = auto()   # ,
    QUESTION = auto()  # ?

    # Delimiters
    LPAREN   = auto()  # (
    RPAREN   = auto()  # )
    LBRACE   = auto()  # {
    RBRACE   = auto()  # }
    LBRACKET = auto()  # [
    RBRACKET = auto()  # ]
    SEMICOLON = auto() # ;
    COLON    = auto()  # :

    # Special
    AT      = auto()   # @ comment marker (handled by lexer, skipped)
    EOF     = auto()
    NEWLINE = auto()

KEYWORDS = {
    'func':  TokenType.FUNC,
    'ret':   TokenType.RET,
    'int':   TokenType.INT,
    'float': TokenType.FLOAT,
    'char':  TokenType.CHAR,
    'arr':   TokenType.ARR,
    'while': TokenType.WHILE,
    'if':    TokenType.IF,
    'else':  TokenType.ELSE,
    'for':   TokenType.FOR,
    'mud':   TokenType.MUD,
    'var':   TokenType.VAR,
    'root':  TokenType.ROOT,
    'a':     TokenType.USER_A,
    'b':     TokenType.USER_B,
    'c':     TokenType.USER_C,
}

@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    col: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, {self.line}:{self.col})"


class LexerError(Exception):
    def __init__(self, msg, line, col):
        super().__init__(f"[LexerError] Line {line}, Col {col}: {msg}")
        self.line = line
        self.col = col


class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.col = 1
        self.tokens = []

    def error(self, msg):
        raise LexerError(msg, self.line, self.col)

    def peek(self, offset=0) -> Optional[str]:
        idx = self.pos + offset
        if idx < len(self.source):
            return self.source[idx]
        return None

    def advance(self) -> str:
        ch = self.source[self.pos]
        self.pos += 1
        if ch == '\n':
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    def match(self, expected: str) -> bool:
        if self.pos < len(self.source) and self.source[self.pos] == expected:
            self.advance()
            return True
        return False

    def skip_whitespace(self):
        while self.pos < len(self.source) and self.source[self.pos] in ' \t\r':
            self.advance()

    def skip_comment(self):
        """@ starts a comment until end of line"""
        while self.pos < len(self.source) and self.source[self.pos] != '\n':
            self.advance()

    def read_string(self) -> Token:
        start_line, start_col = self.line, self.col
        self.advance()  # skip opening "
        buf = []
        while self.pos < len(self.source):
            ch = self.peek()
            if ch == '"':
                self.advance()
                break
            elif ch == '\\':
                self.advance()
                esc = self.advance()
                escapes = {'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"', '0': '\0'}
                buf.append(escapes.get(esc, esc))
            elif ch == '\n':
                self.error("Unterminated string literal")
            else:
                buf.append(self.advance())
        else:
            self.error("Unterminated string literal")
        return Token(TokenType.STRING_LIT, ''.join(buf), start_line, start_col)

    def read_char(self) -> Token:
        start_line, start_col = self.line, self.col
        self.advance()  # skip '
        if self.peek() == '\\':
            self.advance()
            esc = self.advance()
            escapes = {'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', "'": "'", '0': '\0'}
            ch = escapes.get(esc, esc)
        else:
            ch = self.advance()
        if self.peek() != "'":
            self.error("Unterminated char literal")
        self.advance()
        return Token(TokenType.CHAR_LIT, ch, start_line, start_col)

    def read_number(self) -> Token:
        start_line, start_col = self.line, self.col
        buf = []
        is_float = False
        while self.pos < len(self.source) and (self.source[self.pos].isdigit()):
            buf.append(self.advance())
        if self.peek() == '.' and self.peek(1) and self.peek(1).isdigit():
            is_float = True
            buf.append(self.advance())  # .
            while self.pos < len(self.source) and self.source[self.pos].isdigit():
                buf.append(self.advance())
        num_str = ''.join(buf)
        if is_float:
            return Token(TokenType.FLOAT_LIT, num_str, start_line, start_col)
        else:
            return Token(TokenType.INT_LIT, num_str, start_line, start_col)

    def read_ident(self) -> Token:
        start_line, start_col = self.line, self.col
        buf = []
        while self.pos < len(self.source) and (self.source[self.pos].isalnum() or self.source[self.pos] == '_'):
            buf.append(self.advance())
        word = ''.join(buf)
        ttype = KEYWORDS.get(word, TokenType.IDENT)
        return Token(ttype, word, start_line, start_col)

    def tokenize(self) -> list:
        tokens = []

        while self.pos < len(self.source):
            self.skip_whitespace()
            if self.pos >= len(self.source):
                break

            ch = self.peek()
            line, col = self.line, self.col

            # Comment
            if ch == '@':
                self.advance()
                self.skip_comment()
                continue

            # Newline (used as statement separator in some contexts)
            if ch == '\n':
                self.advance()
                continue

            # String
            if ch == '"':
                tokens.append(self.read_string())
                continue

            # Char
            if ch == "'":
                tokens.append(self.read_char())
                continue

            # Number
            if ch.isdigit():
                tokens.append(self.read_number())
                continue

            # Identifier or keyword
            if ch.isalpha() or ch == '_':
                tokens.append(self.read_ident())
                continue

            # Operators and delimiters
            self.advance()

            if ch == '+':
                tokens.append(Token(TokenType.PLUS, '+', line, col))
            elif ch == '-':
                tokens.append(Token(TokenType.MINUS, '-', line, col))
            elif ch == '*':
                tokens.append(Token(TokenType.STAR, '*', line, col))
            elif ch == '/':
                tokens.append(Token(TokenType.SLASH, '/', line, col))
            elif ch == '^':
                tokens.append(Token(TokenType.CARET, '^', line, col))
            elif ch == '=':
                if self.match('='):
                    tokens.append(Token(TokenType.EQ_EQ, '==', line, col))
                else:
                    tokens.append(Token(TokenType.EQ, '=', line, col))
            elif ch == '!':
                if self.match('='):
                    tokens.append(Token(TokenType.NEQ, '!=', line, col))
                else:
                    tokens.append(Token(TokenType.BANG, '!', line, col))
            elif ch == '<':
                if self.match('='):
                    tokens.append(Token(TokenType.LTE, '<=', line, col))
                else:
                    tokens.append(Token(TokenType.LT, '<', line, col))
            elif ch == '>':
                if self.match('='):
                    tokens.append(Token(TokenType.GTE, '>=', line, col))
                else:
                    tokens.append(Token(TokenType.GT, '>', line, col))
            elif ch == '&':
                if self.match('&'):
                    tokens.append(Token(TokenType.AMP_AMP, '&&', line, col))
                else:
                    tokens.append(Token(TokenType.AMP, '&', line, col))
            elif ch == '|':
                if self.match('|'):
                    tokens.append(Token(TokenType.PIPE_PIPE, '||', line, col))
                else:
                    tokens.append(Token(TokenType.PIPE, '|', line, col))
            elif ch == '.':
                tokens.append(Token(TokenType.DOT, '.', line, col))
            elif ch == ',':
                tokens.append(Token(TokenType.COMMA, ',', line, col))
            elif ch == '?':
                tokens.append(Token(TokenType.QUESTION, '?', line, col))
            elif ch == '(':
                tokens.append(Token(TokenType.LPAREN, '(', line, col))
            elif ch == ')':
                tokens.append(Token(TokenType.RPAREN, ')', line, col))
            elif ch == '{':
                tokens.append(Token(TokenType.LBRACE, '{', line, col))
            elif ch == '}':
                tokens.append(Token(TokenType.RBRACE, '}', line, col))
            elif ch == '[':
                tokens.append(Token(TokenType.LBRACKET, '[', line, col))
            elif ch == ']':
                tokens.append(Token(TokenType.RBRACKET, ']', line, col))
            elif ch == ';':
                tokens.append(Token(TokenType.SEMICOLON, ';', line, col))
            elif ch == ':':
                tokens.append(Token(TokenType.COLON, ':', line, col))
            else:
                self.error(f"Unknown character: {ch!r}")

        tokens.append(Token(TokenType.EOF, '', self.line, self.col))
        return tokens
